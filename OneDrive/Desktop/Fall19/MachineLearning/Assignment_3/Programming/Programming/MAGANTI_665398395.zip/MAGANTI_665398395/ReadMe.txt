For the question 3:

Run the code:

a) It will print the train accuracy and test accuracy for different learning rates then after It will plot the graphs for different learning rates with respect to iterations

close the plot each time so that other plot with different learning rate opens

Once you close all the plots with different learning rate's you will get into question b

b)Training and testing accuracies will print for different regularized parameter's and will also plot accuracies for different regularized parameter 